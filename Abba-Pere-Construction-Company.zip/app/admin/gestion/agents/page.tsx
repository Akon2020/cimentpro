"use client"

import type React from "react"

import { useState } from "react"
import { AdminLayout } from "@/components/AdminLayout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Search, Edit, Trash2, Eye, UserCog, Users, Shield } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const agents = [
  {
    id: "AGT-001",
    nom: "Marie Dupont",
    prenom: "Marie",
    email: "marie.dupont@cimentpro.com",
    telephone: "+225 01 02 03 04",
    role: "Caissier",
    statut: "Actif",
    dateEmbauche: "2023-06-15",
    adresse: "Cocody, Abidjan",
    salaire: 250000,
  },
  {
    id: "AGT-002",
    nom: "Jean Martin",
    prenom: "Jean",
    email: "jean.martin@cimentpro.com",
    telephone: "+225 05 06 07 08",
    role: "Comptable",
    statut: "Actif",
    dateEmbauche: "2023-03-20",
    adresse: "Plateau, Abidjan",
    salaire: 350000,
  },
  {
    id: "AGT-003",
    nom: "Sophie Leroy",
    prenom: "Sophie",
    email: "sophie.leroy@cimentpro.com",
    telephone: "+225 07 08 09 10",
    role: "Magasinier",
    statut: "Actif",
    dateEmbauche: "2023-09-10",
    adresse: "Yopougon, Abidjan",
    salaire: 200000,
  },
  {
    id: "AGT-004",
    nom: "Paul Bernard",
    prenom: "Paul",
    email: "paul.bernard@cimentpro.com",
    telephone: "+225 09 10 11 12",
    role: "Commercial",
    statut: "Inactif",
    dateEmbauche: "2022-11-05",
    adresse: "Marcory, Abidjan",
    salaire: 300000,
  },
]

const roles = ["Administrateur", "Caissier", "Comptable", "Magasinier", "Commercial"]

export default function AgentsPage() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingAgent, setEditingAgent] = useState<(typeof agents)[0] | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [formData, setFormData] = useState({
    nom: "",
    prenom: "",
    email: "",
    telephone: "",
    role: "",
    adresse: "",
    salaire: "",
    dateEmbauche: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulation d'enregistrement
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: editingAgent ? "Agent modifié" : "Agent ajouté",
      description: editingAgent
        ? "Les informations de l'agent ont été mises à jour"
        : "Le nouvel agent a été ajouté avec succès",
    })

    // Reset form
    setFormData({
      nom: "",
      prenom: "",
      email: "",
      telephone: "",
      role: "",
      adresse: "",
      salaire: "",
      dateEmbauche: "",
    })
    setEditingAgent(null)
    setIsModalOpen(false)
    setIsSubmitting(false)
  }

  const handleEdit = (agent: (typeof agents)[0]) => {
    setEditingAgent(agent)
    setFormData({
      nom: agent.nom,
      prenom: agent.prenom,
      email: agent.email,
      telephone: agent.telephone,
      role: agent.role,
      adresse: agent.adresse,
      salaire: agent.salaire.toString(),
      dateEmbauche: agent.dateEmbauche,
    })
    setIsModalOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer cet agent ?")) {
      toast({
        title: "Agent supprimé",
        description: "L'agent a été supprimé avec succès",
      })
    }
  }

  const filteredAgents = agents.filter(
    (agent) =>
      agent.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agent.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agent.role.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const agentsActifs = agents.filter((a) => a.statut === "Actif").length
  const totalSalaires = agents.filter((a) => a.statut === "Actif").reduce((sum, a) => sum + a.salaire, 0)

  return (
    <AdminLayout breadcrumbs={[{ label: "Gestion" }, { label: "Agents" }]}>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Gestion des Agents</h1>
            <p className="text-muted-foreground">Gérez vos employés et leurs informations</p>
          </div>
          <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={() => {
                  setEditingAgent(null)
                  setFormData({
                    nom: "",
                    prenom: "",
                    email: "",
                    telephone: "",
                    role: "",
                    adresse: "",
                    salaire: "",
                    dateEmbauche: "",
                  })
                }}
              >
                <Plus className="mr-2 h-4 w-4" />
                Nouvel Agent
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>{editingAgent ? "Modifier l'Agent" : "Nouvel Agent"}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="prenom">Prénom *</Label>
                    <Input
                      id="prenom"
                      value={formData.prenom}
                      onChange={(e) => setFormData({ ...formData, prenom: e.target.value })}
                      placeholder="Prénom de l'agent"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="nom">Nom *</Label>
                    <Input
                      id="nom"
                      value={formData.nom}
                      onChange={(e) => setFormData({ ...formData, nom: e.target.value })}
                      placeholder="Nom de l'agent"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@cimentpro.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="telephone">Téléphone *</Label>
                    <Input
                      id="telephone"
                      value={formData.telephone}
                      onChange={(e) => setFormData({ ...formData, telephone: e.target.value })}
                      placeholder="+225 XX XX XX XX"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="role">Rôle *</Label>
                    <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner un rôle" />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map((role) => (
                          <SelectItem key={role} value={role}>
                            {role}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="dateEmbauche">Date d'Embauche *</Label>
                    <Input
                      id="dateEmbauche"
                      type="date"
                      value={formData.dateEmbauche}
                      onChange={(e) => setFormData({ ...formData, dateEmbauche: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="adresse">Adresse *</Label>
                  <Input
                    id="adresse"
                    value={formData.adresse}
                    onChange={(e) => setFormData({ ...formData, adresse: e.target.value })}
                    placeholder="Adresse complète"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="salaire">Salaire (FCFA) *</Label>
                  <Input
                    id="salaire"
                    type="number"
                    value={formData.salaire}
                    onChange={(e) => setFormData({ ...formData, salaire: e.target.value })}
                    placeholder="Salaire mensuel"
                    required
                  />
                </div>

                <div className="flex space-x-3">
                  <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} className="flex-1">
                    Annuler
                  </Button>
                  <Button type="submit" disabled={isSubmitting} className="flex-1">
                    {isSubmitting ? "Enregistrement..." : editingAgent ? "Modifier" : "Ajouter"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Agents</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{agents.length}</div>
              <p className="text-xs text-muted-foreground">Employés enregistrés</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Agents Actifs</CardTitle>
              <UserCog className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{agentsActifs}</div>
              <p className="text-xs text-muted-foreground">En service</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Masse Salariale</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalSalaires.toLocaleString()} FCFA</div>
              <p className="text-xs text-muted-foreground">Salaires mensuels</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Rôles</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{roles.length}</div>
              <p className="text-xs text-muted-foreground">Types de postes</p>
            </CardContent>
          </Card>
        </div>

        {/* Recherche */}
        <Card>
          <CardHeader>
            <CardTitle>Rechercher un Agent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par nom, email ou rôle..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card>
          <CardHeader>
            <CardTitle>Liste des Agents</CardTitle>
            <CardDescription>Tous vos employés et leurs informations</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nom Complet</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Téléphone</TableHead>
                  <TableHead>Rôle</TableHead>
                  <TableHead>Salaire</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAgents.map((agent) => (
                  <TableRow key={agent.id}>
                    <TableCell className="font-medium">{agent.id}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">
                          {agent.prenom} {agent.nom}
                        </div>
                        <div className="text-sm text-muted-foreground">{agent.adresse}</div>
                      </div>
                    </TableCell>
                    <TableCell>{agent.email}</TableCell>
                    <TableCell>{agent.telephone}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{agent.role}</Badge>
                    </TableCell>
                    <TableCell>{agent.salaire.toLocaleString()} FCFA</TableCell>
                    <TableCell>
                      <Badge variant={agent.statut === "Actif" ? "default" : "secondary"}>{agent.statut}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(agent)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(agent.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  )
}
